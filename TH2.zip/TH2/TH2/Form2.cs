﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;


namespace TH2
{
    public partial class Form2 : Form
    {
        DriveInfo[] drives = DriveInfo.GetDrives();
        public Form2()
        {
            InitializeComponent();

        }
        string[] donvi = { " bytes", " KB", " MB", " GB", " TB" };
        private string quydoi(long size) {
            int cs = 0;
            while (size >= 1024)
            {
                size /= 1024;
                cs++;
            }
            return size.ToString() + donvi[cs];
        }

        private void addNode(TreeNode node)
        {
            string[] folders;
            try
            {
                folders = Directory.GetDirectories(node.Tag.ToString());
            }
            catch (UnauthorizedAccessException)
            {
                return;
            }
            catch (IOException)
            {
                return;
            }

            string[] files;
            try
            {
                files = Directory.GetFiles(node.Tag.ToString());
            }
            catch (UnauthorizedAccessException)
            {
                return;
            }
            catch (IOException)
            {
                return;
            }
            foreach (string folder in folders)
            {

                TreeNode node_child = node.Nodes.Add(Path.GetFileName(folder));
                node_child.Tag = folder;
                node_child.Nodes.Add("temp");

            }
            foreach (string file in files)
            {

                TreeNode node_child = node.Nodes.Add(Path.GetFileName(file));
                node_child.Tag = file;
            }

        }
        private void openItem(ListViewItem item)
        {
            string path = item.Tag.ToString();
            string[] folders;
            string[] files;

            try
            {
                folders = Directory.GetDirectories(path);
            }
            catch (UnauthorizedAccessException)
            {
                return;
            }
            catch (IOException)
            {
                return;
            }

            try
            {
                files = Directory.GetFiles(path);
            }
            catch (UnauthorizedAccessException)
            {
                return;
            }
            catch (IOException)
            {
                return;
            }
            listView1.Items.Clear();
            foreach (string folder in folders)
            {

                ListViewItem item_child = listView1.Items.Add(Path.GetFileName(folder)); 
                item_child.Tag = folder;

            }
            foreach (string file in files)
            {

                ListViewItem item_child = listView1.Items.Add(Path.GetFileName(file));
                item_child.Tag = file;
            }


        }
        private void Form2_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;

            listView1.Columns.Add("Name", 200);
            listView1.Columns.Add("Type", 100);
            listView1.Columns.Add("Size", 100);

            foreach (DriveInfo drive in drives)
            {
                TreeNode node = new TreeNode(drive.Name);
                treeView1.Nodes.Add(node);
                node.Tag = drive.Name;
                addNode(node);

                ListViewItem item = new ListViewItem(drive.Name);
                item.Tag = drive.Name;

                item.SubItems.Add(drive.DriveType.ToString());
                item.SubItems.Add(quydoi(drive.TotalSize));

                listView1.Items.Add(item);

            }

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void treeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNode node = e.Node;
            node.Nodes.RemoveAt(0);
            addNode(node);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                openItem(listView1.SelectedItems[0]);
            }
        }

    }
}
